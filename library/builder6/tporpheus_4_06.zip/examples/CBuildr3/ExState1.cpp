//---------------------------------------------------------------------------
#include <vcl\vcl.h>
#pragma hdrstop

#include "ExState1.h"
//---------------------------------------------------------------------------
#pragma link "OvcState"
#pragma link "OvcBase"
#pragma link "OvcStore"
#pragma link "OvcFiler"
#pragma resource "*.dfm"
TForm1 *Form1;
//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
	: TForm(Owner)
{
}
//---------------------------------------------------------------------------
