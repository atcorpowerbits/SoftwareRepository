//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "ExDbRv20.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma link "OvcBase"
#pragma link "OvcCmbx"
#pragma link "OvcDbRpV"
#pragma link "OvcRptVw"
#pragma link "OvcRvCbx"
#pragma link "OvcRVIdx"
#pragma resource "*.dfm"
TForm1 *Form1;
//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
    : TForm(Owner)
{
}
//---------------------------------------------------------------------------
