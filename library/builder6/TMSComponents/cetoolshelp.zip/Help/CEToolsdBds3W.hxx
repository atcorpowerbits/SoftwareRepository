[CollectionData]
InstallSrc=.
InstallDest=C:\Program Files\Borland\BDS\3.0\Help\ThirdParty
Parent=borland.bds3
MergeType=merge
MergeTOCtitle=CETools  for Win32
MergeTOCurl=ms-help://borland.bds3/CEToolsdBds3W/HtmlHelp/CEToolsClass.htm
Versioning=extended

[Files]
CEToolsdBds3W.hxs
CEToolsdBds3W.hxi

[Filters]
