[CollectionData]
InstallSrc=.
InstallDest=C:\Program Files\Borland\BDS\4.0\Help\ThirdParty
Parent=borland.bds4
MergeType=merge
MergeTOCtitle=CETools  C++ for Win32
MergeTOCurl=ms-help://borland.bds4/CEToolsbBds4W/HtmlHelp/CEToolsClass.htm
Versioning=extended

[Files]
CEToolsbBds4W.hxs
CEToolsbBds4W.hxi

[Filters]
