[CollectionData]
InstallSrc=.
InstallDest=C:\Program Files\Borland\BDS\4.0\Help\ThirdParty
Parent=borland.bds4
MergeType=merge
MergeTOCtitle=CETools  Delphi for Win32
MergeTOCurl=ms-help://borland.bds4/CEToolsdBds4W/HtmlHelp/CEToolsClass.htm
Versioning=extended

[Files]
CEToolsdBds4W.hxs
CEToolsdBds4W.hxi

[Filters]
