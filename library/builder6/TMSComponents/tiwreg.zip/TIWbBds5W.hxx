[CollectionData]
InstallSrc=.
InstallDest=bdshelp
Parent=borland.bds5
MergeType=merge
MergeTOCtitle=TMS Instrumentation Workshop C++ for Win32
MergeTOCurl=ms-help://borland.bds5/TIWbBds5W/HtmlHelp/VrJogMeterTVrJogMeterClass.htm
Versioning=extended

[Files]
TIWbBds5W.hxs
TIWbBds5W.hxi

[Filters]
