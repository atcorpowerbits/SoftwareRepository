[CollectionData]
InstallSrc=.
InstallDest=C:\Program Files\Borland\BDS\3.0\Help\ThirdParty
Parent=borland.bds3
MergeType=merge
MergeTOCtitle=TMS Instrumentation Workshop for Win32
MergeTOCurl=ms-help://borland.bds3/TIWdBds3W/HtmlHelp/VrJogMeterTVrJogMeterClass.htm
Versioning=extended

[Files]
TIWdBds3W.hxs
TIWdBds3W.hxi

[Filters]
