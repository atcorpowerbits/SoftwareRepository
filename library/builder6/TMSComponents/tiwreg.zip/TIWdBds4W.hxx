[CollectionData]
InstallSrc=.
InstallDest=bdshelp
Parent=borland.bds4
MergeType=merge
MergeTOCtitle=TMS Instrumentation Workshop Delphi for Win32
MergeTOCurl=ms-help://borland.bds4/TIWdBds4W/HtmlHelp/VrJogMeterTVrJogMeterClass.htm
Versioning=extended

[Files]
TIWdBds4W.hxs
TIWdBds4W.hxi

[Filters]
