[CollectionData]
InstallSrc=.
InstallDest=bdshelp
Parent=borland.bds4
MergeType=merge
MergeTOCtitle=TMS Instrumentation Workshop C++ for Win32
MergeTOCurl=ms-help://borland.bds4/TIWbBds4W/HtmlHelp/VrJogMeterTVrJogMeterClass.htm
Versioning=extended

[Files]
TIWbBds4W.hxs
TIWbBds4W.hxi

[Filters]
