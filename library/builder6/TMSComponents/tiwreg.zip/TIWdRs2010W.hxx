[CollectionData]
InstallSrc=.
InstallDest=bdshelp
Parent=embarcadero.rs2010
MergeType=merge
MergeTOCtitle=TMS Instrumentation Workshop Delphi for Win32
MergeTOCurl=ms-help://embarcadero.rs2010/TIWdRs2010W/HtmlHelp/VrJogMeterTVrJogMeterClass.htm
Versioning=extended

[Files]
TIWdRs2010W.hxs
TIWdRs2010W.hxi

[Filters]
