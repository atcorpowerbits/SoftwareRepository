[CollectionData]
InstallSrc=.
InstallDest=bdshelp
Parent=embarcadero.rs2009
MergeType=merge
MergeTOCtitle=TMS Instrumentation Workshop Delphi for Win32
MergeTOCurl=ms-help://embarcadero.rs2009/TIWdRs2009W/HtmlHelp/VrJogMeterTVrJogMeterClass.htm
Versioning=extended

[Files]
TIWdRs2009W.hxs
TIWdRs2009W.hxi

[Filters]
