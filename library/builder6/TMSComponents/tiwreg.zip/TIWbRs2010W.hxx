[CollectionData]
InstallSrc=.
InstallDest=bdshelp
Parent=embarcadero.rs2010
MergeType=merge
MergeTOCtitle=TMS Instrumentation Workshop C++ for Win32
MergeTOCurl=ms-help://embarcadero.rs2010/TIWbRs2010W/HtmlHelp/VrJogMeterTVrJogMeterClass.htm
Versioning=extended

[Files]
TIWbRs2010W.hxs
TIWbRs2010W.hxi

[Filters]
