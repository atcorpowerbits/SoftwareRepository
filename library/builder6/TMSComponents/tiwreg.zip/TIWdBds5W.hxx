[CollectionData]
InstallSrc=.
InstallDest=bdshelp
Parent=borland.bds5
MergeType=merge
MergeTOCtitle=TMS Instrumentation Workshop Delphi for Win32
MergeTOCurl=ms-help://borland.bds5/TIWdBds5W/HtmlHelp/VrJogMeterTVrJogMeterClass.htm
Versioning=extended

[Files]
TIWdBds5W.hxs
TIWdBds5W.hxi

[Filters]
