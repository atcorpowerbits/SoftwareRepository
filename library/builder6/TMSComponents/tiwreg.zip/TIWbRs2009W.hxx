[CollectionData]
InstallSrc=.
InstallDest=bdshelp
Parent=embarcadero.rs2009
MergeType=merge
MergeTOCtitle=TMS Instrumentation Workshop C++ for Win32
MergeTOCurl=ms-help://embarcadero.rs2009/TIWbRs2009W/HtmlHelp/VrJogMeterTVrJogMeterClass.htm
Versioning=extended

[Files]
TIWbRs2009W.hxs
TIWbRs2009W.hxi

[Filters]
