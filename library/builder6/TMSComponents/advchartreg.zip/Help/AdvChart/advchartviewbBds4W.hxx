[CollectionData]
InstallSrc=.
InstallDest=bdshelp
Parent=borland.bds4
MergeType=merge
MergeTOCtitle=TAdvChartView help C++ for Win32
MergeTOCurl=ms-help://borland.bds4/AdvChartViewbBds4W/HtmlHelp/AdvChartViewTAdvChartViewClass.htm
Versioning=extended

[Files]
AdvChartViewbBds4W.hxs
AdvChartViewbBds4W.hxi

[Filters]
