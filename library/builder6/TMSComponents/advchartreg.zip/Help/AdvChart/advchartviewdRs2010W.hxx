[CollectionData]
InstallSrc=.
InstallDest=bdshelp
Parent=embarcadero.rs2010
MergeType=merge
MergeTOCtitle=TAdvChartView help Delphi for Win32
MergeTOCurl=ms-help://embarcadero.rs2010/advchartviewdRs2010W/HtmlHelp/AboutClass.htm
Versioning=extended

[Files]
advchartviewdRs2010W.hxs
advchartviewdRs2010W.hxi

[Filters]
