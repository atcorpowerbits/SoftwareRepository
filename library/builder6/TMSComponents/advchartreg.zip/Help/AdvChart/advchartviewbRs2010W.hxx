[CollectionData]
InstallSrc=.
InstallDest=bdshelp
Parent=embarcadero.rs2010
MergeType=merge
MergeTOCtitle=TAdvChartView help C++ for Win32
MergeTOCurl=ms-help://embarcadero.rs2010/advchartviewbRs2010W/HtmlHelp/AboutClass.htm
Versioning=extended

[Files]
advchartviewbRs2010W.hxs
advchartviewbRs2010W.hxi

[Filters]
