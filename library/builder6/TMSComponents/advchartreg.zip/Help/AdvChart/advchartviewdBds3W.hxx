[CollectionData]
InstallSrc=.
InstallDest=C:\Program Files\Borland\BDS\3.0\Help\ThirdParty
Parent=borland.bds3
MergeType=merge
MergeTOCtitle=TAdvChartView help for Win32
MergeTOCurl=ms-help://borland.bds3/AdvChartViewdBds3W/HtmlHelp/AdvChartViewTAdvChartViewClass.htm
Versioning=extended

[Files]
AdvChartViewdBds3W.hxs
AdvChartViewdBds3W.hxi

[Filters]
