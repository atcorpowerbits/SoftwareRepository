[CollectionData]
InstallSrc=.
InstallDest=bdshelp
Parent=borland.bds5
MergeType=merge
MergeTOCtitle=TAdvChartView help Delphi for Win32
MergeTOCurl=ms-help://borland.bds5/AdvChartViewdBds5W/HtmlHelp/AdvChartViewTAdvChartViewClass.htm
Versioning=extended

[Files]
AdvChartViewdBds5W.hxs
AdvChartViewdBds5W.hxi

[Filters]
