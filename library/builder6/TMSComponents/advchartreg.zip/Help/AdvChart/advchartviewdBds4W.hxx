[CollectionData]
InstallSrc=.
InstallDest=bdshelp
Parent=borland.bds4
MergeType=merge
MergeTOCtitle=TAdvChartView help Delphi for Win32
MergeTOCurl=ms-help://borland.bds4/AdvChartViewdBds4W/HtmlHelp/AdvChartViewTAdvChartViewClass.htm
Versioning=extended

[Files]
AdvChartViewdBds4W.hxs
AdvChartViewdBds4W.hxi

[Filters]
