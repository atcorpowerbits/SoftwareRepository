[CollectionData]
InstallSrc=.
InstallDest=bdshelp
Parent=embarcadero.rs2009
MergeType=merge
MergeTOCtitle=TAdvChartView help C++ for Win32
MergeTOCurl=ms-help://embarcadero.rs2009/AdvChartViewbRs2009W/HtmlHelp/AdvChartViewTAdvChartViewClass.htm
Versioning=extended

[Files]
AdvChartViewbRs2009W.hxs
AdvChartViewbRs2009W.hxi

[Filters]
