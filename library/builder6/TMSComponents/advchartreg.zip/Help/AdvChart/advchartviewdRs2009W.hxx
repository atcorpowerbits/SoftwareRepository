[CollectionData]
InstallSrc=.
InstallDest=bdshelp
Parent=embarcadero.rs2009
MergeType=merge
MergeTOCtitle=TAdvChartView help Delphi for Win32
MergeTOCurl=ms-help://embarcadero.rs2009/AdvChartViewdRs2009W/HtmlHelp/AdvChartViewTAdvChartViewClass.htm
Versioning=extended

[Files]
AdvChartViewdRs2009W.hxs
AdvChartViewdRs2009W.hxi

[Filters]
