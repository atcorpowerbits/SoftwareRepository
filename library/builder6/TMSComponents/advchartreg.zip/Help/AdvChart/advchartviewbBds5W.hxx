[CollectionData]
InstallSrc=.
InstallDest=bdshelp
Parent=borland.bds5
MergeType=merge
MergeTOCtitle=TAdvChartView help C++ for Win32
MergeTOCurl=ms-help://borland.bds5/AdvChartViewbBds5W/HtmlHelp/AdvChartViewTAdvChartViewClass.htm
Versioning=extended

[Files]
AdvChartViewbBds5W.hxs
AdvChartViewbBds5W.hxi

[Filters]
