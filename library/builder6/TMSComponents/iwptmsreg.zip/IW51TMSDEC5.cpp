//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop
#pragma link "wininet.lib"
USERES("IW51TMSDEC5.res");
USEPACKAGE("vcl50.bpi");
USEUNIT("IWTMSDEREG.pas");
USEPACKAGE("Intraweb_51_50.bpi");
USEPACKAGE("dclIntraweb_51_50.bpi");
USEPACKAGE("vclsmp50.bpi");
USEPACKAGE("Vcldb50.bpi");
USEPACKAGE("IW51TMSC5.bpi");
//---------------------------------------------------------------------------
#pragma package(smart_init)
//---------------------------------------------------------------------------

//   Package source.
//---------------------------------------------------------------------------

#pragma argsused
int WINAPI DllEntryPoint(HINSTANCE hinst, unsigned long reason, void*)
{
        return 1;
}
//---------------------------------------------------------------------------
