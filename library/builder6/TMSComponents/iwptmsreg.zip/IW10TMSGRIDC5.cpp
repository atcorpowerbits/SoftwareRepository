//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop
#pragma link "wininet.lib"
USERES("IW10TMSGRIDC5.res");
USEUNIT("IWDBAdvWebGridReg.pas");
USERES("IWDBAdvWebGridReg.dcr");
USEUNIT("IWAdvWebGridReg.pas");
USERES("IWAdvWebGridReg.dcr");
USEPACKAGE("Vcl50.bpi");
USEPACKAGE("Vcldb50.bpi");
USEPACKAGE("dclIntraweb_100_50.bpi");
USEPACKAGE("Intraweb_100_50.bpi");
USEPACKAGE("IW10TMSC5.bpi");
//---------------------------------------------------------------------------
#pragma package(smart_init)
//---------------------------------------------------------------------------

//   Package source.
//---------------------------------------------------------------------------

#pragma argsused
int WINAPI DllEntryPoint(HINSTANCE hinst, unsigned long reason, void*)
{
        return 1;
}
//---------------------------------------------------------------------------
