//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop
#pragma link "wininet.lib"
USERES("IW72TMSDEC5.res");
USEPACKAGE("vcl50.bpi");
USEUNIT("IWTMSDEREG.pas");
USEPACKAGE("vcldb50.bpi");
USEPACKAGE("vclx50.bpi");
USEPACKAGE("vclsmp50.bpi");
USEPACKAGE("Intraweb_72_50.bpi");
USEPACKAGE("dclIntraweb_72_50.bpi");
USEPACKAGE("IW72TMSC5.bpi");
USEUNIT("iwadvtoolbuttonde.pas");
USEUNIT("iwadvselectorde.pas");
//---------------------------------------------------------------------------
#pragma package(smart_init)
//---------------------------------------------------------------------------

//   Package source.
//---------------------------------------------------------------------------

#pragma argsused
int WINAPI DllEntryPoint(HINSTANCE hinst, unsigned long reason, void*)
{
        return 1;
}
//---------------------------------------------------------------------------
