**********************************************************************
* Author: TMS Software                                               *
*         Copyright � 2002-2009                                      *
*         E-mail: info@tmssoftware.com                               *
*         Web: http://www.tmssoftware.com                            *
**********************************************************************

TMS IntraWeb Components for
- Delphi 5.0/6.0/7.0/2005/2006/2007/2009/2010
- C++Builder 5.0/6.0/2006/2007/2009/2010

--------------------------------------------------------------------------------------------
TMS IntraWeb Components for IntraWeb 5.1.x, 6.0.x, 7.0.x, 7.1.x, 7.2.x, 8.0.x, 9.0.x, 10.0.x 
--------------------------------------------------------------------------------------------

Installation:

NOTE: FOR ADDITIONAL QUESTIONS: see http://www.tmssoftware.com/tmsiwfaq.htm

For Delphi (IntraWeb 5.1.x)
---------------------------

Copy tmsdefs51.inc to tmsdefs.inc ! (Registered version only)

Install package files
  - IW51TMSD5.DPK (Delphi 5)
  - IW51TMSD6.DPK (Delphi 6)
  - IW51TMSD7.DPK (Delphi 7)

Install package files
  - IW51TMSDED5.DPK (Delphi 5)
  - IW51TMSDED6.DPK (Delphi 6)
  - IW51TMSDED7.DPK (Delphi 7)


For Delphi (IntraWeb 6.0.x)
---------------------------

Copy tmsdefs6.inc to tmsdefs.inc ! (Registered version only)

Install package files
  - IW6TMSD5.DPK (Delphi 5)
  - IW6TMSD6.DPK (Delphi 6)
  - IW6TMSD7.DPK (Delphi 7)

Install package files
  - IW6TMSDED5.DPK (Delphi 5)
  - IW6TMSDED6.DPK (Delphi 6)
  - IW6TMSDED7.DPK (Delphi 7)


For Delphi (IntraWeb 7.0.x)
---------------------------

Copy tmsdefs7.inc to tmsdefs.inc ! (Registered version only)

Install package files
  - IW7TMSD5.DPK (Delphi 5)
  - IW7TMSD6.DPK (Delphi 6)
  - IW7TMSD7.DPK (Delphi 7)

Install package files
  - IW7TMSDED5.DPK (Delphi 5)
  - IW7TMSDED6.DPK (Delphi 6)
  - IW7TMSDED7.DPK (Delphi 7)


For Delphi (IntraWeb 7.1.x)
---------------------------

Copy tmsdefs71.inc to tmsdefs.inc ! (Registered version only)

Install package files
  - IW71TMSD5.DPK (Delphi 5)
  - IW71TMSD6.DPK (Delphi 6)
  - IW71TMSD7.DPK (Delphi 7)

Install package files
  - IW71TMSDED5.DPK (Delphi 5)
  - IW71TMSDED6.DPK (Delphi 6)
  - IW71TMSDED7.DPK (Delphi 7)


For Delphi (IntraWeb 7.2.x)
---------------------------

Copy tmsdefs72.inc to tmsdefs.inc ! (Registered version only)

Install package files
  - IW72TMSD5.DPK (Delphi 5)
  - IW72TMSD6.DPK (Delphi 6)
  - IW72TMSD7.DPK (Delphi 7)

  - IW72TMSD2005.bdsproj (Delphi 2005)

Install package files
  - IW72TMSDED5.DPK (Delphi 5)
  - IW72TMSDED6.DPK (Delphi 6)
  - IW72TMSDED7.DPK (Delphi 7)

  - IW72TMSDED2005.bdsproj (Delphi 2005)

IMPORTANT NOTICE: If you're using a 7.2 version prior to v7.2.32, comment
the line {$DEFINE TMSIW72_NEW} from tmsdefs.inc

IMPORTANT NOTICE: If you're using a 7.2 version prior to v7.2.18, comment
the line {$DEFINE TMSIW72} from tmsdefs.inc

For Delphi (IntraWeb 8.0.x)
---------------------------

Copy tmsdefs8.inc to tmsdefs.inc ! (Registered version only)

Install package files
  - IW8TMSD5.DPK (Delphi 5)
  - IW8TMSD6.DPK (Delphi 6)
  - IW8TMSD7.DPK (Delphi 7)

  - IW8TMSD2005.bdsproj (Delphi 2005)
  - IW8TMSD2006.bdsproj (Delphi 2006)

Install package files
  - IW8TMSDED5.DPK (Delphi 5)
  - IW8TMSDED6.DPK (Delphi 6)
  - IW8TMSDED7.DPK (Delphi 7)

  - IW8TMSDED2005.bdsproj (Delphi 2005)
  - IW8TMSDED2006.bdsproj (Delphi 2006)


For Delphi (IntraWeb 9.0.x)
---------------------------

Copy tmsdefs9.inc to tmsdefs.inc ! (Registered version only)

Install package files
  - IW9TMSD5.dpk (Delphi 5)
  - IW9TMSD6.dpk (Delphi 6)
  - IW9TMSD7.dpk (Delphi 7)
  - IW9TMSD2005.bdsproj (Delphi 2005)
  - IW9TMSD2006.bdsproj (Delphi 2006)
  - IW9TMSD2007.dproj (Delphi 2007)

Install package files
  - IW9TMSDED5.dpk (Delphi 5)
  - IW9TMSDED6.dpk (Delphi 6)
  - IW9TMSDED7.dpk (Delphi 7)
  - IW9TMSDED2005.bdsproj (Delphi 2005)
  - IW9TMSDED2006.bdsproj (Delphi 2006)
  - IW9TMSDED2007.dproj (Delphi 2007)

For Delphi 2009 (IntraWeb 10.0.x)
---------------------------------

Copy tmsdefs10.inc to tmsdefs.inc ! (Registered version only)

Install package files
  - IW10TMSD2009.dproj 
  - IW10TMSDED2009.dproj 
  - IW10TMSGRIDD2009.dproj 
  - IW10TMSGRIDDED2009.dproj 
  - IW10TMSXLSD2009.dproj 


For C++Builder (IntraWeb 5.1.x)
-------------------------------

Copy tmsdefs51.inc to tmsdefs.inc ! (Registered version only)

Install package files
  - IW51TMSC5.DPK (C++Builder 5)
  - IW51TMSC6.DPK (C++Builder 6)

Install package files
  - IW51TMSDEC5.DPK (C++Builder 5)
  - IW51TMSDEC6.DPK (C++Builder 6)


For C++Builder (IntraWeb 6.0.x)
-------------------------------

Copy tmsdefs6.inc to tmsdefs.inc ! (Registered version only)

Install package files
  - IW6TMSC5.DPK (C++Builder 5)
  - IW6TMSC6.DPK (C++Builder 6)

Install package files
  - IW6TMSDEC5.DPK (C++Builder 5)
  - IW6TMSDEC6.DPK (C++Builder 6)


For C++Builder (IntraWeb 7.0.x)
-------------------------------

Copy tmsdefs7.inc to tmsdefs.inc ! (Registered version only)

Install package files
  - IW7TMSC5.DPK (C++Builder 5)
  - IW7TMSC6.DPK (C++Builder 6)

Install package files
  - IW7TMSDEC5.DPK (C++Builder 5)
  - IW7TMSDEC6.DPK (C++Builder 6)


For C++Builder (IntraWeb 7.1.x)
-------------------------------

Copy tmsdefs71.inc to tmsdefs.inc ! (Registered version only)

Install package files
  - IW71TMSC5.DPK (C++Builder 5)
  - IW71TMSC6.DPK (C++Builder 6)

Install package files
  - IW71TMSDEC5.DPK (C++Builder 5)
  - IW71TMSDEC6.DPK (C++Builder 6)

For C++Builder (IntraWeb 7.2.x)
-------------------------------

Copy tmsdefs72.inc to tmsdefs.inc ! (Registered version only)

Install package files
  - IW72TMSC5.DPK (C++Builder 5)
  - IW72TMSC6.DPK (C++Builder 6)

Install package files
  - IW72TMSDEC5.DPK (C++Builder 5)
  - IW72TMSDEC6.DPK (C++Builder 6)


For C++Builder (IntraWeb 8.x)
-----------------------------

Copy tmsdefs8.inc to tmsdefs.inc ! (Registered version only)

Install package files
  - IW8TMSC5.DPK (C++Builder 5)
  - IW8TMSC6.DPK (C++Builder 6)
  - IW8TMSD2006.bdsproj (C++Builder 2006)

Install package files
  - IW8TMSDEC5.DPK (C++Builder 5)
  - IW8TMSDEC6.DPK (C++Builder 6)
  - IW8TMSDED2006.bdsproj (C++Builder 2006)


For C++Builder (IntraWeb 9.x)
-----------------------------

Copy tmsdefs9.inc to tmsdefs.inc ! (Registered version only)

Install package files
  - IW9TMSC5.BPK (C++Builder 5)
  - IW9TMSC6.BPK (C++Builder 6)
  - IW9TMSD2006.bdsproj (C++Builder 2006)

Install package files
  - IW9TMSDEC5.BPK (C++Builder 5)
  - IW9TMSDEC6.BPK (C++Builder 6)
  - IW9TMSDED2006.bdsproj (C++Builder 2006)

For C++Builder 2009 (IntraWeb 10.0.x)
-------------------------------------

Copy tmsdefs10.inc to tmsdefs.inc ! (Registered version only)

Install package files
  - IW10TMSD2009.cbproj 
  - IW10TMSDED2009.cbproj 
  - IW10TMSGRIDD2009.cbproj 
  - IW10TMSGRIDDED2009.cbproj 
  - IW10TMSXLSD2009.cbproj 


-------------------------------
Installing the debug add-on OCX
-------------------------------

From the DOS command line run : REGSVR32 DebugOutXControl1.ocx

For Delphi (IntraWeb 5.1.x)
---------------------------

Install package files 
  - IW51TMSGRIDD5.DPK (Delphi 5) 
  - IW51TMSGRIDD6.DPK (Delphi 6)
  - IW51TMSGRIDD7.DPK (Delphi 7)

Install package files
  - IW51TMSGRIDDED5.DPK (Delphi 5)
  - IW51TMSGRIDDED6.DPK (Delphi 6)
  - IW51TMSGRIDDED7.DPK (Delphi 7)

For Delphi (IntraWeb 6.0.x)
---------------------------

Install package files 
  - IW6TMSGRIDD5.DPK (Delphi 5) 
  - IW6TMSGRIDD6.DPK (Delphi 6)
  - IW6TMSGRIDD7.DPK (Delphi 7)

Install package files
  - IW6TMSGRIDDED5.DPK (Delphi 5)
  - IW6TMSGRIDDED6.DPK (Delphi 6)
  - IW6TMSGRIDDED7.DPK (Delphi 7)

For Delphi (IntraWeb 7.0.x)
---------------------------

Install package files 
  - IW7TMSGRIDD5.DPK (Delphi 5) 
  - IW7TMSGRIDD6.DPK (Delphi 6)
  - IW7TMSGRIDD7.DPK (Delphi 7)

Install package files
  - IW7TMSGRIDDED5.DPK (Delphi 5)
  - IW7TMSGRIDDED6.DPK (Delphi 6)
  - IW7TMSGRIDDED7.DPK (Delphi 7)

For Delphi (IntraWeb 7.1.x)
---------------------------

Install package files 
  - IW71TMSGRIDD5.DPK (Delphi 5) 
  - IW71TMSGRIDD6.DPK (Delphi 6)
  - IW71TMSGRIDD7.DPK (Delphi 7)

Install package files
  - IW71TMSGRIDDED5.DPK (Delphi 5)
  - IW71TMSGRIDDED6.DPK (Delphi 6)
  - IW71TMSGRIDDED7.DPK (Delphi 7)

For Delphi (IntraWeb 7.2.x)
---------------------------

Install package files 
  - IW72TMSGRIDD5.DPK (Delphi 5) 
  - IW72TMSGRIDD6.DPK (Delphi 6)
  - IW72TMSGRIDD7.DPK (Delphi 7)

  - IW72TMSGRIDD2005.bdsproj (Delphi 2005)

Install package files
  - IW72TMSGRIDDED5.DPK (Delphi 5)
  - IW72TMSGRIDDED6.DPK (Delphi 6)
  - IW72TMSGRIDDED7.DPK (Delphi 7)

  - IW72TMSGRIDDED2005.bdsproj (Delphi 2005)

For Delphi (IntraWeb 8.0.x)
---------------------------

Install package files 
  - IW8TMSGRIDD5.DPK (Delphi 5) 
  - IW8TMSGRIDD6.DPK (Delphi 6)
  - IW8TMSGRIDD7.DPK (Delphi 7)

  - IW8TMSGRIDD2005.bdsproj (Delphi 2005)
  - IW8TMSGRIDD2006.bdsproj (Delphi 2006)

Install package files
  - IW8TMSGRIDDED5.DPK (Delphi 5)
  - IW8TMSGRIDDED6.DPK (Delphi 6)
  - IW8TMSGRIDDED7.DPK (Delphi 7)

  - IW8TMSGRIDDED2005.bdsproj (Delphi 2005)
  - IW8TMSGRIDDED2006.bdsproj (Delphi 2006)

For Delphi (IntraWeb 9.0.x)
---------------------------

Install package files 
  - IW9TMSGRIDD5.dpk (Delphi 5)
  - IW9TMSGRIDD6.dpk (Delphi 6)
  - IW9TMSGRIDD7.dpk (Delphi 7)
  - IW9TMSGRIDD2005.bdsproj (Delphi 2005)
  - IW9TMSGRIDD2006.bdsproj (Delphi 2006)
  - IW9TMSGRIDD2007.dproj (Delphi 2007)

Install package files
  - IW9TMSGRIDDED5.dpk (Delphi 5)
  - IW9TMSGRIDDED6.dpk (Delphi 6)
  - IW9TMSGRIDDED7.dpk (Delphi 7)
  - IW9TMSGRIDDED2005.bdsproj (Delphi 2005)
  - IW9TMSGRIDDED2006.bdsproj (Delphi 2006)
  - IW9TMSGRIDDED2007.dproj (Delphi 2007)

  - IW9TMSXLSD6.dpk (Delphi 6)
  - IW9TMSXLSD7.dpk (Delphi 7)
  - IW9TMSXLSD2005.bdsproj (Delphi 2005)
  - IW9TMSXLSD2006.bdsproj (Delphi 2006)
  - IW9TMSXLSD2007.dproj (Delphi 2007)

----------------------------------------------------------
TMS IntraWeb Components Pro Script Edition for IntraWeb 
----------------------------------------------------------

For Delphi (IntraWeb 6.0.x)
---------------------------

Install package files 
  - IW6TMSSED5.DPK (Delphi 5) 
  - IW6TMSSED6.DPK (Delphi 6)
  - IW6TMSSED7.DPK (Delphi 7)


For Delphi (IntraWeb 7.0.x)
---------------------------

Install package files 
  - IW7TMSSED5.DPK (Delphi 5) 
  - IW7TMSSED6.DPK (Delphi 6)
  - IW7TMSSED7.DPK (Delphi 7)

For Delphi (IntraWeb 7.1.x)
---------------------------

Install package files 
  - IW71TMSSED5.DPK (Delphi 5) 
  - IW71TMSSED6.DPK (Delphi 6)
  - IW71TMSSED7.DPK (Delphi 7)

For Delphi (IntraWeb 7.2.x)
---------------------------

Install package files 
  - IW72TMSSED5.DPK (Delphi 5) 
  - IW72TMSSED6.DPK (Delphi 6)
  - IW72TMSSED7.DPK (Delphi 7)

  - IW72TMSSED2005.bdsproj (Delphi 2005)

For Delphi (IntraWeb 8.0.x)
---------------------------

Install package files 
  - IW8TMSSED5.DPK (Delphi 5) 
  - IW8TMSSED6.DPK (Delphi 6)
  - IW8TMSSED7.DPK (Delphi 7)

  - IW8TMSSED2005.bdsproj (Delphi 2005)
  - IW8TMSSED2006.bdsproj (Delphi 2006)

For Delphi (IntraWeb 9.0.x)
---------------------------

Install package files 
  - IW9TMSSED5.dpk (Delphi 5)
  - IW9TMSSED6.dpk (Delphi 6)
  - IW9TMSSED7.dpk (Delphi 7)
  - IW9TMSSED2005.bdsproj (Delphi 2005)
  - IW9TMSSED2006.bdsproj (Delphi 2006)
  - IW9TMSSED2007.dproj (Delphi 2007)

For C++Builder (IntraWeb 6.0.x)
-------------------------------

Install package files
  - IW6TMSGRIDC5.DPK (C++Builder 5)
  - IW6TMSGRIDC6.DPK (C++Builder 6)

Install package files
  - IW6TMSGRIDDEC5.DPK (C++Builder 5)
  - IW6TMSGRIDDEC6.DPK (C++Builder 6)


For C++Builder (IntraWeb 7.0.x)
-------------------------------

Install package files
  - IW7TMSGRIDC5.DPK (C++Builder 5)
  - IW7TMSGRIDC6.DPK (C++Builder 6)

Install package files
  - IW7TMSGRIDDEC5.DPK (C++Builder 5)
  - IW7TMSGRIDDEC6.DPK (C++Builder 6)

For C++Builder (IntraWeb 7.1.x)
-------------------------------

Install package files
  - IW71TMSGRIDC5.DPK (C++Builder 5)
  - IW71TMSGRIDC6.DPK (C++Builder 6)

Install package files
  - IW71TMSGRIDDEC5.DPK (C++Builder 5)
  - IW71TMSGRIDDEC6.DPK (C++Builder 6)

For C++Builder (IntraWeb 7.2.x)
-------------------------------

Install package files
  - IW72TMSGRIDC5.DPK (C++Builder 5)
  - IW72TMSGRIDC6.DPK (C++Builder 6)

Install package files
  - IW72TMSGRIDDEC5.DPK (C++Builder 5)
  - IW72TMSGRIDDEC6.DPK (C++Builder 6)

For C++Builder (IntraWeb 8.x)
-------------------------------

Install package files
  - IW8TMSGRIDC5.DPK (C++Builder 5)
  - IW8TMSGRIDC6.DPK (C++Builder 6)
  - IW8TMSGRIDD2006.bdsproj (C++Builder 2006)

Install package files
  - IW8TMSGRIDDEC5.DPK (C++Builder 5)
  - IW8TMSGRIDDEC6.DPK (C++Builder 6)
  - IW8TMSGRIDDED2006.DPK (C++Builder 2006)

For C++Builder (IntraWeb 9.x)
-------------------------------

Install package files
  - IW9TMSGRIDC5.bpk (C++Builder 5)
  - IW9TMSGRIDC6.bpk (C++Builder 6)
  - IW9TMSGRIDD2006.bdsproj (C++Builder 2006)

Install package files
  - IW9TMSGRIDDEC5.bpk (C++Builder 5)
  - IW9TMSGRIDDEC6.bpk (C++Builder 6)
  - IW9TMSGRIDDEC2006.bpk (C++Builder 2006)

  - IW9TMSXLSC6.bpk (C++Builder 6)
  - IW9TMSXLSC2006.bpk (C++Builder 2006)



------------------------------------------
Installing the grid & menu gallery support
------------------------------------------

Create the directory:

  C:\Program Files\tmssoftware\TMSIWPRO\Preferences

and copy the contents of the Gallery directory in this
new directory, ie.

  C:\Program Files\tmssoftware\TMSIWPRO\Preferences\Grids
  C:\Program Files\tmssoftware\TMSIWPRO\Preferences\Menus


Installing the Script Edition version with the TMS Component Pack
-----------------------------------------------------------------

Remove the AdvMemo* files from the TMS IntraWeb Component Pack directory
Remove references to AdvMemo* files from the IWxTMSSEDxx.DPK package file
Add a reference to the TMSxx.DCP file to the requires list of the IWxTMSSEDxx.DPK package file



******************************************************
*                                                    *
*            I M P O R T A N T   N O T E S           *
*                                                    *
******************************************************

 TMS IntraWeb Components for IntraWeb v5.1.x require Intraweb v5.1.9 or higher !

 TMS IntraWeb Components for IntraWeb v6.0.x require Intraweb v6.0.15 or higher !

 TMS IntraWeb Components for IntraWeb v7.0.x require Intraweb v7.0.3 or higher !

 TMS IntraWeb Components for IntraWeb v7.1.x require Intraweb v7.1.9 or higher !

 TMS IntraWeb Components for IntraWeb v7.2.x require Intraweb v7.2.32 or higher !

 TMS IntraWeb Components for IntraWeb v8.0.x require Intraweb v8.0.3 or higher !

 TMS IntraWeb Components for IntraWeb v9.0.x require Intraweb v9.0.15 or higher !
