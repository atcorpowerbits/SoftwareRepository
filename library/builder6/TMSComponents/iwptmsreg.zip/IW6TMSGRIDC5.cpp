//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop
#pragma link "wininet.lib"
USERES("IW6TMSGRIDC5.res");
USEUNIT("IWDBAdvWebGridReg.pas");
USERES("IWDBAdvWebGridReg.dcr");
USEUNIT("IWAdvWebGridReg.pas");
USERES("IWAdvWebGridReg.dcr");
USEPACKAGE("Vcl50.bpi");
USEPACKAGE("Vcldb50.bpi");
USEPACKAGE("IW6TMSC5.bpi");
USEPACKAGE("Intraweb_60_50.bpi");
//---------------------------------------------------------------------------
#pragma package(smart_init)
//---------------------------------------------------------------------------

//   Package source.
//---------------------------------------------------------------------------

#pragma argsused
int WINAPI DllEntryPoint(HINSTANCE hinst, unsigned long reason, void*)
{
        return 1;
}
//---------------------------------------------------------------------------
