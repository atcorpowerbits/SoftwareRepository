//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop
#pragma link "wininet.lib"
USERES("IW7TMSC5.res");
USEPACKAGE("vcl50.bpi");
USEPACKAGE("vcldb50.bpi");
USEUNIT("IWTMSCTRLSREG.pas");
USERES("IWTMSCTRLSREG.dcr");
USEUNIT("IWDBTMSCTRLSREG.pas");
USERES("IWDBTMSCTRLSREG.dcr");
USEPACKAGE("Intraweb_70_50.bpi");
USEPACKAGE("IntrawebDB_70_50.bpi");
//---------------------------------------------------------------------------
#pragma package(smart_init)
//---------------------------------------------------------------------------

//   Package source.
//---------------------------------------------------------------------------

#pragma argsused
int WINAPI DllEntryPoint(HINSTANCE hinst, unsigned long reason, void*)
{
        return 1;
}
//---------------------------------------------------------------------------
