//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop
#pragma link "wininet.lib"
USERES("IW7TMSGRIDC5.res");
USEUNIT("IWDBAdvWebGridReg.pas");
USERES("IWDBAdvWebGridReg.dcr");
USEUNIT("IWAdvWebGridReg.pas");
USERES("IWAdvWebGridReg.dcr");
USEPACKAGE("Vcl50.bpi");
USEPACKAGE("Vcldb50.bpi");
USEPACKAGE("IW7TMSC5.bpi");
USEPACKAGE("Intraweb_70_50.bpi");
//---------------------------------------------------------------------------
#pragma package(smart_init)
//---------------------------------------------------------------------------

//   Package source.
//---------------------------------------------------------------------------

#pragma argsused
int WINAPI DllEntryPoint(HINSTANCE hinst, unsigned long reason, void*)
{
        return 1;
}
//---------------------------------------------------------------------------
