//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop
#pragma link "wininet.lib"
USERES("IW72TMSGRIDC5.res");
USEUNIT("IWDBAdvWebGridReg.pas");
USERES("IWDBAdvWebGridReg.dcr");
USEUNIT("IWAdvWebGridReg.pas");
USERES("IWAdvWebGridReg.dcr");
USEPACKAGE("Vcl50.bpi");
USEPACKAGE("Vcldb50.bpi");
USEPACKAGE("dclIntraweb_72_50.bpi");
USEPACKAGE("Intraweb_72_50.bpi");
USEPACKAGE("IW72TMSC5.bpi");
//---------------------------------------------------------------------------
#pragma package(smart_init)
//---------------------------------------------------------------------------

//   Package source.
//---------------------------------------------------------------------------

#pragma argsused
int WINAPI DllEntryPoint(HINSTANCE hinst, unsigned long reason, void*)
{
        return 1;
}
//---------------------------------------------------------------------------
