//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop
#pragma link "wininet.lib"
USERES("IW7TMSDEC5.res");
USEPACKAGE("vcl50.bpi");
USEUNIT("IWTMSDEREG.pas");
USEPACKAGE("vcldb50.bpi");
USEPACKAGE("vclx50.bpi");
USEPACKAGE("vclsmp50.bpi");
USEPACKAGE("IW7TMSC5.bpi");
USEPACKAGE("dclIntraweb_70_50.bpi");
USEPACKAGE("Intraweb_70_50.bpi");
//---------------------------------------------------------------------------
#pragma package(smart_init)
//---------------------------------------------------------------------------

//   Package source.
//---------------------------------------------------------------------------

#pragma argsused
int WINAPI DllEntryPoint(HINSTANCE hinst, unsigned long reason, void*)
{
        return 1;
}
//---------------------------------------------------------------------------
