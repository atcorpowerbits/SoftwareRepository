//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop
#pragma link "wininet.lib"
USERES("IW10TMSC5.res");
USEPACKAGE("vcl50.bpi");
USEPACKAGE("vcldb50.bpi");
USEUNIT("IWTMSCTRLSREG.pas");
USERES("IWTMSCTRLSREG.dcr");
USEUNIT("IWDBTMSCTRLSREG.pas");
USERES("IWDBTMSCTRLSREG.dcr");
USEPACKAGE("IntrawebDB_100_50.bpi");
USEPACKAGE("Intraweb_100_50.bpi");
USEPACKAGE("dclIntraweb_100_50.bpi");
//---------------------------------------------------------------------------
#pragma package(smart_init)
//---------------------------------------------------------------------------

//   Package source.
//---------------------------------------------------------------------------

#pragma argsused
int WINAPI DllEntryPoint(HINSTANCE hinst, unsigned long reason, void*)
{
        return 1;
}
//---------------------------------------------------------------------------
