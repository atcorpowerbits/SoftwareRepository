//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop
#pragma link "wininet.lib"
USERES("IW8TMSGRIDDEC5.res");
USEPACKAGE("vcl50.bpi");
USEUNIT("IWDBAdvWebGridDE.pas");
USEUNIT("IWAdvWebGridDE.pas");
USEPACKAGE("Vcldb50.bpi");
USEPACKAGE("Intraweb_80_50.bpi");
USEPACKAGE("dclIntraweb_80_50.bpi");
USEPACKAGE("IW8TMSC5.bpi");
USEPACKAGE("IW8TMSGRIDC5.bpi");
USEPACKAGE("IW8TMSDEC5.bpi");
//---------------------------------------------------------------------------
#pragma package(smart_init)
//---------------------------------------------------------------------------

//   Package source.
//---------------------------------------------------------------------------

#pragma argsused
int WINAPI DllEntryPoint(HINSTANCE hinst, unsigned long reason, void*)
{
        return 1;
}
//---------------------------------------------------------------------------
