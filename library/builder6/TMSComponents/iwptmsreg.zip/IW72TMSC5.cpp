//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop
#pragma link "wininet.lib"
USERES("IW72TMSC5.res");
USEPACKAGE("vcl50.bpi");
USEPACKAGE("vcldb50.bpi");
USEUNIT("IWTMSCTRLSREG.pas");
USERES("IWTMSCTRLSREG.dcr");
USEUNIT("IWDBTMSCTRLSREG.pas");
USERES("IWDBTMSCTRLSREG.dcr");
USEPACKAGE("IntrawebDB_72_50.bpi");
USEPACKAGE("Intraweb_72_50.bpi");
USEPACKAGE("dclIntraweb_72_50.bpi");
//---------------------------------------------------------------------------
#pragma package(smart_init)
//---------------------------------------------------------------------------

//   Package source.
//---------------------------------------------------------------------------

#pragma argsused
int WINAPI DllEntryPoint(HINSTANCE hinst, unsigned long reason, void*)
{
        return 1;
}
//---------------------------------------------------------------------------
