//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop
#pragma link "wininet.lib"
USERES("IW51TMSC5.res");
USEPACKAGE("vcl50.bpi");
USEUNIT("IWTMSCTRLSREG.pas");
USERES("IWTMSCTRLSREG.dcr");
USEPACKAGE("Intraweb_51_50.bpi");
//---------------------------------------------------------------------------
#pragma package(smart_init)
//---------------------------------------------------------------------------

//   Package source.
//---------------------------------------------------------------------------

#pragma argsused
int WINAPI DllEntryPoint(HINSTANCE hinst, unsigned long reason, void*)
{
        return 1;
}
//---------------------------------------------------------------------------
