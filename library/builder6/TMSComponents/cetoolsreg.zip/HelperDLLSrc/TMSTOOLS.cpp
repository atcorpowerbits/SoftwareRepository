// TMSTOOLS.cpp : Defines the entry point for the DLL application.
//

#include "stdafx.h"
#include "TMSTOOLS.h"
#include "tlhelp32.h"


BOOL APIENTRY DllMain( HANDLE hModule, 
                       DWORD  ul_reason_for_call, 
                       LPVOID lpReserved
					 )
{
    switch (ul_reason_for_call)
	{
		case DLL_PROCESS_ATTACH:
		case DLL_THREAD_ATTACH:
		case DLL_THREAD_DETACH:
		case DLL_PROCESS_DETACH:
			break;
    }
    return TRUE;
}


// This is an example of an exported variable
TMSTOOLS_API int nTMSTOOLS=0;

// Shows a messagebox on the Pocket PC

TMSTOOLS_API void fnMESSAGE(DWORD cbInput,
   BYTE  *pInput,
   DWORD *pcbOutput,
   BYTE  **ppOutput,
   BYTE  *RAPIStream)
{
  *ppOutput = NULL;
  *pcbOutput = 0;

  LPCTSTR c;

  c = (LPCTSTR)pInput;

  MessageBox(0,c,TEXT("Info"),MB_OK);
}

// Retrieves the list of running processes on the Pocket PC

TMSTOOLS_API void fnPROCS(DWORD cbInput,
   BYTE  *pInput,
   DWORD *pcbOutput,
   BYTE  **ppOutput,
   BYTE  *RAPIStream)
{
  LPCTSTR c;
  HANDLE TH;
  PROCESSENTRY32 lppe;
  LPWSTR procs;
  DWORD dwCurSize;

  *ppOutput = NULL;
  *pcbOutput = 0;

  c = (LPCTSTR)pInput;

  procs = NULL;
  dwCurSize = 1;

  TH = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS,0);

  lppe.dwSize = sizeof(lppe);
  if (Process32First(TH,&lppe))
  { 
    dwCurSize += (wcslen(lppe.szExeFile)*sizeof(TCHAR)) + (sizeof(TCHAR));

    procs = (LPWSTR)LocalAlloc(LPTR,dwCurSize);

	wcscat(procs, lppe.szExeFile);
    wcscat(procs, L",");

    lppe.dwSize = sizeof(lppe);
	while (Process32Next(TH,&lppe))
	{
      dwCurSize += (wcslen(lppe.szExeFile)*sizeof(TCHAR)) + (sizeof(TCHAR));

      procs = (LPWSTR)LocalReAlloc((HLOCAL)procs, dwCurSize, LMEM_MOVEABLE);

      wcscat(procs, lppe.szExeFile);
	  wcscat(procs, L",");
      
	  lppe.dwSize = sizeof(lppe);
    }
  }

  *ppOutput = (PBYTE)procs;
  *pcbOutput = dwCurSize;

  CloseToolhelp32Snapshot(TH);
}

// Retrieves the list of loaded modules on the Pocket PC

TMSTOOLS_API void fnMODULES(DWORD cbInput,
   BYTE  *pInput,
   DWORD *pcbOutput,
   BYTE  **ppOutput,
   BYTE  *RAPIStream)
{
  LPCTSTR c;
  HANDLE TH;
  MODULEENTRY32 me;
  LPWSTR procs;
  DWORD dwCurSize;

  *ppOutput = NULL;
  *pcbOutput = 0;

  c = (LPCTSTR)pInput;

  procs = NULL;
  dwCurSize = 1;

  TH = CreateToolhelp32Snapshot(TH32CS_SNAPMODULE | TH32CS_GETALLMODS, 0);

  me.dwSize = sizeof(me);
  if (Module32First(TH,&me))
  { 
    dwCurSize += (wcslen(me.szModule)*sizeof(TCHAR)) + (sizeof(TCHAR));

    procs = (LPWSTR)LocalAlloc(LPTR,dwCurSize);

	wcscat(procs, me.szModule);
    wcscat(procs, L",");

    me.dwSize = sizeof(me);
	while (Module32Next(TH,&me))
	{
      dwCurSize += (wcslen(me.szModule)*sizeof(TCHAR)) + (sizeof(TCHAR));

      procs = (LPWSTR)LocalReAlloc((HLOCAL)procs, dwCurSize, LMEM_MOVEABLE);

      wcscat(procs, me.szModule);
	  wcscat(procs, L",");
      
	  me.dwSize = sizeof(me);
    }
  }

  *ppOutput = (PBYTE)procs;
  *pcbOutput = dwCurSize;

  CloseToolhelp32Snapshot(TH);
}

// Looks for the Window handle on the Pocket PC

TMSTOOLS_API void fnFINDWINDOW(DWORD cbInput,
   BYTE  *pInput,
   DWORD *pcbOutput,
   BYTE  **ppOutput,
   BYTE  *RAPIStream)
{
  LPCTSTR c;
  HWND hwnd;

  *ppOutput = NULL;
  *pcbOutput = 0;

  c = (LPCTSTR)pInput;

  hwnd = FindWindow(NULL, c);
  
  *pcbOutput = DWORD(hwnd);
}


bool CALLBACK EnumWindowProc(HWND hwnd, LPARAM lParam)
{
  TCHAR szText[256];
//  int NewSize;
//  char *p;
//  LPCTSTR pText;

  GetWindowText(hwnd,(LPTSTR)szText,sizeof(szText));

  MessageBox(0,szText,TEXT("info"),MB_OK);

  
  // lparam is pointer to pointer of string
//  p = (char *)lParam;

//  pText = (LPCTSTR)p;

//  NewSize = wcslen(pText) + wcslen(szText) + 1;

//  if (pText == NULL)
//    pText = (LPCTSTR)LocalAlloc(LPTR, NewSize);
//  else
//    pText = (LPCTSTR)LocalReAlloc((HLOCAL)pText, NewSize, LMEM_MOVEABLE);
	
  return true;
}


TMSTOOLS_API void fnENUMWINDOWS(DWORD cbInput,
   BYTE  *pInput,
   DWORD *pcbOutput,
   BYTE  **ppOutput,
   BYTE  *RAPIStream)
{
  LPWSTR procs;
  LPARAM lp;


  *ppOutput = NULL;
  *pcbOutput = 0;

  procs = NULL;

  lp = (LPARAM)&procs;

  EnumWindows((WNDENUMPROC)EnumWindowProc,lp);
 
  *ppOutput = (PBYTE)procs;
  *pcbOutput = wcslen(procs);
  
}


TMSTOOLS_API void fnGETLOCALTIME(DWORD cbInput,
   BYTE  *pInput,
   DWORD *pcbOutput,
   BYTE  **ppOutput,
   BYTE  *RAPIStream)
{
   SYSTEMTIME *st;

   st = (SYSTEMTIME *)LocalAlloc(LPTR, sizeof(SYSTEMTIME));

   GetLocalTime(st);

   *ppOutput = (PBYTE)st;
   *pcbOutput = sizeof(SYSTEMTIME); 
}

TMSTOOLS_API void fnSETLOCALTIME(DWORD cbInput,
   BYTE  *pInput,
   DWORD *pcbOutput,
   BYTE  **ppOutput,
   BYTE  *RAPIStream)
{
   SYSTEMTIME *st;

   if (cbInput > 0)
   {
     st = (SYSTEMTIME *)pInput;
     SetLocalTime(st);
   }

   *ppOutput = NULL;
   *pcbOutput = 0; 
}

TMSTOOLS_API void fnSENDKEYDOWN(DWORD cbInput,
   BYTE  *pInput,
   DWORD *pcbOutput,
   BYTE  **ppOutput,
   BYTE  *RAPIStream)
{
   HWND hwnd;
   int wpar;

   hwnd = GetForegroundWindow();

   wpar = (int)pInput;


   SendMessage(hwnd,WM_KEYDOWN, wpar,0);
   
   *ppOutput = NULL;
   *pcbOutput = 0; 
}

TMSTOOLS_API void fnSENDKEYUP(DWORD cbInput,
   BYTE  *pInput,
   DWORD *pcbOutput,
   BYTE  **ppOutput,
   BYTE  *RAPIStream)
{
   HWND hwnd;
   int wpar;

   hwnd = GetForegroundWindow();

   wpar = (int)pInput;


   SendMessage(hwnd,WM_KEYUP, wpar,0);
   
   *ppOutput = NULL;
   *pcbOutput = 0; 
}

TMSTOOLS_API void fnSENDCHAR(DWORD cbInput,
   BYTE  *pInput,
   DWORD *pcbOutput,
   BYTE  **ppOutput,
   BYTE  *RAPIStream)
{
   HWND hwnd;
   int wpar;

   hwnd = GetForegroundWindow();

   hwnd = GetFocus();

   wpar = (int)pInput;

   SendMessage(hwnd,WM_CHAR, wpar,0);
   
   *ppOutput = NULL;
   *pcbOutput = 0; 
}



// This is the constructor of a class that has been exported.
// see TMSTOOLS.h for the class definition
CTMSTOOLS::CTMSTOOLS()
{ 
	return; 
}

