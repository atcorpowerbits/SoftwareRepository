
// The following ifdef block is the standard way of creating macros which make exporting 
// from a DLL simpler. All files within this DLL are compiled with the TMSTOOLS_EXPORTS
// symbol defined on the command line. this symbol should not be defined on any project
// that uses this DLL. This way any other project whose source files include this file see 
// TMSTOOLS_API functions as being imported from a DLL, wheras this DLL sees symbols
// defined with this macro as being exported.

#ifdef TMSTOOLS_EXPORTS
#define TMSTOOLS_API __declspec(dllexport)
#else
#define TMSTOOLS_API __declspec(dllimport)
#endif

// This class is exported from the TMSTOOLS.dll
class TMSTOOLS_API CTMSTOOLS {
public:
	CTMSTOOLS(void);
	// TODO: add your methods here.
};

extern TMSTOOLS_API int nTMSTOOLS;

extern "C" TMSTOOLS_API void fnMESSAGE(DWORD cbInput,
   BYTE  *pInput,
   DWORD *pcbOutput,
   BYTE  **ppOutput,
   BYTE  *RAPIStream);

extern "C" TMSTOOLS_API void fnPROCS(DWORD cbInput,
   BYTE  *pInput,
   DWORD *pcbOutput,
   BYTE  **ppOutput,
   BYTE  *RAPIStream);

extern "C" TMSTOOLS_API void fnMODULES(DWORD cbInput,
   BYTE  *pInput,
   DWORD *pcbOutput,
   BYTE  **ppOutput,
   BYTE  *RAPIStream);

extern "C" TMSTOOLS_API void fnFINDWINDOW(DWORD cbInput,
   BYTE  *pInput,
   DWORD *pcbOutput,
   BYTE  **ppOutput,
   BYTE  *RAPIStream);

extern "C" TMSTOOLS_API void fnENUMWINDOWS(DWORD cbInput,
   BYTE  *pInput,
   DWORD *pcbOutput,
   BYTE  **ppOutput,
   BYTE  *RAPIStream);

extern "C" TMSTOOLS_API void fnGETLOCALTIME(DWORD cbInput,
   BYTE  *pInput,
   DWORD *pcbOutput,
   BYTE  **ppOutput,
   BYTE  *RAPIStream);

extern "C" TMSTOOLS_API void fnSETLOCALTIME(DWORD cbInput,
   BYTE  *pInput,
   DWORD *pcbOutput,
   BYTE  **ppOutput,
   BYTE  *RAPIStream);

extern "C" TMSTOOLS_API void fnSENDKEYDOWN(DWORD cbInput,
   BYTE  *pInput,
   DWORD *pcbOutput,
   BYTE  **ppOutput,
   BYTE  *RAPIStream);

extern "C" TMSTOOLS_API void fnSENDKEYUP(DWORD cbInput,
   BYTE  *pInput,
   DWORD *pcbOutput,
   BYTE  **ppOutput,
   BYTE  *RAPIStream);

extern "C" TMSTOOLS_API void fnSENDCHAR(DWORD cbInput,
   BYTE  *pInput,
   DWORD *pcbOutput,
   BYTE  **ppOutput,
   BYTE  *RAPIStream);
