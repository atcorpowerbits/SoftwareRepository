//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop
USERES("TMSASPGRIDC5.res");
USEPACKAGE("vcl50.bpi");
USEUNIT("MiscMathLibReg.pas");
USEUNIT("AdvFormula.pas");
USEUNIT("AdvPars.pas");
USEUNIT("AdvSprd.pas");
USEUNIT("aspgreg.pas");
USEUNIT("CalcEdit.pas");
USEUNIT("calcereg.pas");
USERES("calcereg.dcr");
USEUNIT("ESBMaths.pas");
USEUNIT("ESBMathsLib.pas");
USERES("ESBMathsLib.dcr");
USEUNIT("MiscMathLib.pas");
USEPACKAGE("tmsc5.bpi");
//---------------------------------------------------------------------------
#pragma package(smart_init)
//---------------------------------------------------------------------------

//   Package source.
//---------------------------------------------------------------------------

#pragma argsused
int WINAPI DllEntryPoint(HINSTANCE hinst, unsigned long reason, void*)
{
        return 1;
}
//---------------------------------------------------------------------------
