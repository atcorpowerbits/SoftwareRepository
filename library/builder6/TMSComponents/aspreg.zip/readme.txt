*************************************
* TAdvSpreadGrid registered version *
*************************************

TAdvSpreadGrid is an add-on for TAdvStringGrid or
the TMS Component Pack and must be installed with 
TMS Component Pack 4.x or higher.

Installation with TAdvStringGrid:
---------------------------------

Add the files included to the directory where 
TAdvStringGrid is installed, open the TAdvStringGrid 
package file and add the file ASPGREG.PAS to the package 
file and compile.
The TAdvSpreadGrid and related component icons will
appear on the component palette and is ready to be used.


Installation with TMS Component Pack:
-------------------------------------

Unzip into a new folder and add the folder to your library path.

Delphi 5:

- Open TMSASPGRIDD5.DPK and compile+install

Delphi 6:

- Open TMSASPGRIDD6.DPK and compile+install

Delphi 7:

- Open TMSASPGRIDD7.DPK and compile+install

Delphi 2005:

- Open TMSASPGRIDD2005.BDSPROJ and compile+install

Delphi 2006:

- Open TMSASPGRIDD2006.BDSPROJ and compile+install

Delphi 2007:

- Open TMSASPGRIDD2007.DPROJ and compile+install

Delphi 2009:

- Open TMSASPGRIDD2009.DPROJ and compile+install

Delphi 2010:

- Open TMSASPGRIDD2010.DPROJ and compile+install

C++Builder 5:

- Open TMSASPGRIDC5.BPK and compile+install

C++Builder 6:

- Open TMSASPGRIDC6.BPK and compile+install

C++Builder 2006:

- Open TMSASPGRIDC2006.BDSPROJ and compile+install

C++Builder 2007:

- Open TMSASPGRIDC2007.CBPROJ and compile+install

C++Builder 2009:

- Open TMSASPGRIDC2009.CBPROJ and compile+install

C++Builder 2010:

- Open TMSASPGRIDC2010.CBPROJ and compile+install